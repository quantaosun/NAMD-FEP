#!/bin/bash
# This script is written for the purpose to do ligand mutation free energy pertubation. 
# I assume you use the web server "Feprepare" to generate "all" necessary input files
# towards NAMD simlation. This script can help to change the "lambda by lambda"
# simulation sequence to "all lambda in one" simulation, making the simulation easier
# to handle and analysis later. The directory location to run this script should be 
# the "complex" or "solvent", respectively. This one is for solvent leg.
##email to quantaosun@gmail.com if there is any issues or errors. 

# It should be advised; the author of this script only have preliminary knowledge of 
# coding, so use this script at your own risk !

############ NVT script modification ##################################
#cp conf_solvent/nvt_equil.namd ./
head -n 13 nvt_equil.namd > output1
cat parameter_patch.txt >> output1
tail -n +14 nvt_equil.namd > output2
#sed -i 's/ionized.fep/ionized_solvent.fep/' output2
cat output2 >> output1
mv output1 nvt_equil_modi.namd


############ NPT script modification #####################################
#cp conf_solvent/npt_equil.namd ./
head -n 13 npt_equil.namd > output3
cat parameter_patch.txt >> output3
tail -n +14 npt_equil.namd > output4
#sed -i 's/ionized.fep/ionized_solvent.fep/' output4
cat output4 >> output3
mv output3 npt_equil_modi.namd

############### Production script modification #################################

#cp conf_solvent/md_forward_1.namd ./

tail -n 3 md_forward_1.namd > tmp2.txt
echo "alchEquilSteps          0
    set numSteps            500000       ; # 0.5 ns as a total

   runFEP 0.0 1.0 0.0625 $numSteps" > tmp2.txt                  # overwrite the original Lambda0 Lambda2 format, 16 lambda windows

cat tmp2.txt >> md_forward_1.namd

#To uncomment lines 139 through 141 to turn off the one by one simulation:

sed -i '139,141 s/^/#/' md_forward_1.namd                         #double check the line numbers.

head -n 123 md_forward_1.namd > outputA
tail -n +124 md_forward_1.namd > outputB
echo "source     ../fep.tcl" >> outputA
cat outputB >> outputA
mv outputA md_forward_1.namd
#################### To substitute the alchFile ##############                                                 
head -n 13 md_forward_1.namd > output5
cat parameter_patch.txt >> output5
tail -n +14 md_forward_1.namd > output6
#sed -i 's/ionized.fep/ionized_solvent.fep/' output6                  # correct the B column with -1
sed -i '/^alchDecouple/s/off/yes/' output6                            # turn on the "alchDecouple"
cat output6 >> output5
mv output5 md_forward_modi.namd
